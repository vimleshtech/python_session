class compute:

     def get_data(self):
          self.a  = int(input('enter data :'))
          self.b  = int(input('enter data :'))

     def add(self):
          c =self.a+self.b

          print(c)

     
     def __init__(add):
          add.a =0
          add.b=0
          print('object is created')

     
     def __init__(add,count):
          if count=='india':
               add.a=1
               add.b=1
          else:
               add.a=0
               add.b=0
     

     def __del__(a):
          print(a,' object is removed, so we cannot use furter')
          
     
#o = compute()
o = compute('india')
o.add()

del o

#print(o) #error 
