class calc:

     def add(a,b,c):
          print(b+c)

     def sub(a,b,c):
          print(b-c)




class dcalc(calc): #exted clac to dcalc
     def mul(a,b,c):
          print(b*c)



#o = dcalc()
#o.mul(11,2)
#o.add(11,2)
          
