data = input('enter . sperated value :')

o = data.split('.')

for i in range(1,len(o)):
     if int(o[i-1]) >      int(o[i]):
          print (int(o[i-1]), ' is greater than ',int(o[i]))
          
     else:
          print (int(o[i]), ' is greater than ',int(o[i-1]))



#convert lower to upper and upper to lower

data = input('enter data / string ')

d = list(data) #convert char by char / convert to list

for c in d:
     if c.islower():
          print (c.upper(),end='')
     else:
          print (c.lower(),end='')


#
name ='raman'
i = list(name)
print(i)

for c in i:
     print(ord(c))
     





          
