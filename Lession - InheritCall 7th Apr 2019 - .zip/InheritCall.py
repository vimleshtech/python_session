from InheritenceEx import *

class test(dcalc):
     def hello(a):
          print('hello')



o = test()
o.mul(1,2)
o.add(33,4)
o.sub(44,5)
o.hello()
