
x =[1,2,3,4]
y =[15,25,3,48]

for i in x:
    print(i)
    


for i in y:
    print(i)
    


for i,j in zip(x,y):
    print(i,j)
    
