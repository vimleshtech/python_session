import numpy as np
import matplotlib.pyplot as plt


x = [33,44,55,66,77]
y = [33,44,55,66,77]

x = np.array(x)
y = np.array(y)

plt.plot(x,y)
  
plt.xlabel('x dataset')
plt.ylabel('y dataset')
plt.title('header..')
plt.grid()

plt.show()



    

