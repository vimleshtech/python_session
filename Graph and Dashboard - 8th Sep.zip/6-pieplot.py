import matplotlib.pyplot as plt
 
days = [1,2,3,4,5] 
sleeping =[7,8,6,11,7]
eating = [2,3,4,3,2]
working =[7,8,7,2,2]
playing = [8,5,7,8,13]
x = [7,2,2,13]
#SUM(slices)  = 24  , 7/24 , 2/24 , 2/24 , 13/24 
activities = ['sleeping','eating','working','playing','dd']
cols = ['c','m','r','b']

 
plt.pie(days,
  labels=activities,
  colors=cols,
  startangle=90,
  shadow= True,
  explode=(.1,0.1,0,.1,.1),
  autopct='%1.4f%%')
 
plt.title('Pie Plot')
plt.show()


