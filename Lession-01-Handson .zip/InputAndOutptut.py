print('hi',end=' ') #end : will replace by given key over \n
print('raman')

i = input('enter id ')
name = input('enter name ')
sal = int(input('enter sal '))

print(i)
print(name)
print(sal)


print(type(i))
print(type(name))
print(type(sal))

ysal = sal *12
print(ysal)

