i =1   #init 
while i<10: #condition
     print(i)
     i +=1  # incrementer


#print in reverse
i =10
while i>0:
     print(i)
     i-=1

#for
for x in range(1,10): #from 1 to <10 , default incrmenter is 1
     print(x)

for x in range(1,10,2): #from 1 to <10 , default incrmenter is 1
     print(x)

#rev
for i in range(10,0,-1):
        print(i)
        
'''
example
test

'''

"""
"""

