hs = 78
es = 98
cs = 80
ms = 88

total = hs+es+cs+ms
avg = total/4

print('total score is ',total)
print('average score is ',avg)

if avg>=80:
 print('Grade A')
elif avg>=60:
     print('Grade B')
elif avg>=40:
          print('Grade C')
          print('Grade C')
          print('Grade C')
else:
     print('Grade D')



#
a =[11,22,33,4,55]
if 22 not in a:
     print('not match')

else:
     print('match')




     
     
