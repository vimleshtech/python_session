'''
open(path,mode)  - create new file , open the existing file
                 - default mode r  (read)
path : physical location of file
mode :
     r - read
     w - write
     a - append

read()  - read all content from file
readline() - read first line / line by line
readlines() - read all content and convert to list(every line of file become one item of list)
write(str)  - write content to file
close() - save and close the instance of file 
     
'''
def save_data(src):
     f = open(src,'a')
     f.write('hi,\n this is test file.\n thank you \n')
     f.close()


def read_data(src):
     try:
          f = open(src,'r')
          #print(f.read())
          #print(f.readline())
          for x in f.readlines(): #
               print(x)

          f.close()
     except FileNotFoundError as e:
          print(e)
     except:
          print('It seems file is not exit at given location or with given name')
          
save_data('testfile.txt')
read_data('xtestfile.txt')





          
     

     
     
