'''
 Database : is realational schema(group of objects) where data can be stored in tabular format on client server architecture
 
            -MY SQL Server
            -MS SQL Server
            -Oracle         
            -IBM DB2
            etc.
     MY SQL Server
               host: localhost/ ip address
                     localhost     
               user    : root  
               password: root
               database: 
               
            
    SQL Commands:
          show databases;    --show list of exisiting database
          create database <dbname>; -- create new database
          use <dbname> ; --change/switch database
          show tables;   -- show list if existing tables

                         --create new table
          create table <tblname> (col_name type, col_name type,col_name type);

          desc <tblname> ; --show details of table

          insert into <tblname> (col1,col2... )valeus(value1,'value2 - string');

          
          select * from <tblname> ; --show all data, *: show all columns
          select col1,col2 from <tblname>;


          select * from <tblname> where col1 =33;

          delete from <tblname> ; -- remove all rows


          delete from <tblname> where col = 1 ;--remove matching rows


          update <tblname> set colname ='new value' where col1 = 4;

          
 Introduction
           install mysql-connector
           ----------------------
           
           cd "C:\Program Files (x86)\Microsoft Visual Studio\Shared\Python36_64\Scripts"
           pip install <package_name>;
           pip install mysql-connector
           
      
 Connections
      import mysql.connector  as con

      c = con.connect(host='',user='',password='',database='')
      
      
      
           
 Executing queries 
 Transactions 
 Handling error


'''
import mysql.connector  as con

c = con.connect(host='localhost',user='root',password='root',database='db_connect')
cur = c.cursor()

#read data from sql 
cur.execute('select * from users')
out = cur.fetchall()
for r in out:
     print(r[1],r[2])


#write to sql table
cur.execute("insert into users(uid,name,email) values(20,'Raman','raman@gmail.com')")
c.commit() #to save file

     
     






      
