import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name #'192.33.445.333' 
port =4041    

s.connect((host, port))

print (s.recv(1024))
s.close() #clsoe the connection




