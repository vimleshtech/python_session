import socket               # Import socket module
import random

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
print(host) #print machine name


port = 4041             # Reserve a port for your service, any 2-6 digit unique number
s.bind((host, port))    # Bind to the port, start the server

#"LHTU05CG7300QJQ:4040"

s.listen(10) #max 10 connection allowed

#a,b =11,22


print('pleae wait ...')

while True: #is someone connected to server
    
    c, addr = s.accept()     # Establish connection with client.
    print('we have recived the call/requrest from ',addr)
    otp = str(random.randint(1000,9999))
    
    c.send(otp.encode()) #encode() - encryp the data before send over the network
    c.close()                # Close the connection
    



