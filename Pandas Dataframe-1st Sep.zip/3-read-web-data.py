url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data'

import pandas as pd
out = pd.read_csv(url)
print(out)

print(out.shape)




out.to_csv('mydata.csv',index=False)
