
import pandas as pd


data1 = {'eid':[11,22,1,3,5],
         'name':['nitin','jatin','divya','ayush','nidhi']}


df1  =  pd.DataFrame(data1)
print(df1)

data2 = {'eid':[110,220,10],
         'name':['Raman','Monika','Rohit']}


df2  =  pd.DataFrame(data2)
print(df2)
print(df1.shape)
print(df2.shape)

df2['gender'] = ['male','female','male']

#merge by column , axis = 1 (column)
out = pd.concat([df1,df2], axis=1)
print(out)



#merge by column , axis = 0 (row)
out = pd.concat([df1,df2], axis=0)
print(out)








