##############join : 
#######################
import pandas as pd

#emp dataframe
data1 = {'eid':[11,22,1,3,5],
         'name':['nitin','jatin','divya','ayush','nidhi'],
         'gender':['male','male','femlae','male','female'],
         'country':['india','UK','Aus','India','US']
         }


emp  =  pd.DataFrame(data1)
print(emp)


##salary dataframe
data2 = {'eid':[11,60,1],
         'basic':[67000,89000,68000],
         'hra':[32000,44000,34000],
         'da':[10000,23000,13000]
         }


sal  =  pd.DataFrame(data2)
print(sal)
print(emp.shape)
print(sal.shape)


##inner join
inner_out  = pd.merge(emp,sal,on='eid',how='inner')
print(inner_out)

##left join
left_out  = pd.merge(emp,sal,on='eid',how='left')
print(left_out)

##right_join
right_out  = pd.merge(emp,sal,on='eid',how='right')
print(right_out)

#outer
outer_out  = pd.merge(emp,sal,on='eid',how='outer')
print(outer_out[['name','basic']])





out = f_suffix = pd.merge(emp, emp, left_on='eid',right_on='eid',how='outer',suffixes=('_left','_right'))
print(out)


###drop column and rows

o = outer_out.fillna(0)
print(o)

outer_out['hra'] = outer_out['hra'].fillna(1000)
print(outer_out)



o = outer_out.drop(outer_out.index[0:3])
print(o)


o = outer_out.drop([1,2,6]) 
print(o)


emp.drop(emp[emp['gender'] =='male'].index, inplace = True)
print(emp)











































         



