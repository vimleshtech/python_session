import pandas as pd

#Create empty dataframe
data = pd.DataFrame()
print(data)

#Create dataframe from dict
d ={'eid':[11,222,444,555,1,2,3],
    'ename':['Nitin','Jatin','Divya','Kshitiz','Rohit','Monika','Jyoti'],
    'gender':['male','male','female','male','male','female','female'],
    'salary':[78000,56000,23000,90000,120000,15000,56000],
    'age':[24,25,34,27,41,23,30]}


#Convert dict to dataframe
emp = pd.DataFrame(data=d)
print(emp)

#print index
print(emp.index)

#print coluns
print(emp.columns)

#rename the column
emp.columns=['emp_code','emp_name','gender','salary','age']
print(emp)

#rename index
emp.index=['a','b','c','d','e','f','g']
print(emp)

#Data Extraction : read selected column
print(emp['salary'])
print(emp[['salary','gender']])
print(emp[['salary','gender','emp_code']])

##head : show row from top
print(emp.head()) #default row count is 5

#tail : show row from buttom
print(emp.tail())

#shape : show row and col count
print(emp.shape)


##write/save datafrme in file .csv, .xlsx
#emp.to_csv(r'C:\Users\vkumar15\Documents\TestFolder\emp.csv')

#save file without index
emp.to_csv(r'C:\Users\vkumar15\Documents\TestFolder\emp.csv',index=False)

#save file to excel
emp.to_excel(r'C:\Users\vkumar15\Documents\TestFolder\emp.xlsx',sheet_name='test', index=False)
#,sheets="emp"




























