import pandas as pd

#read csv file
#e = pd.read_csv(r'C:\Users\vkumar15\Documents\TestFolder\emp.csv')
#print(e)

#read excel

data= pd.read_excel(r'C:\Users\vkumar15\Documents\TestFolder\emp.xlsx',sheet_name='Sheet2')
print(data)


#add new column in existing dataframe
work_exp = [4,5,2,6,9,12,4,6,4,7]

data['exp'] = work_exp
print(data)

#Row and col index
# row_index, col_index
print(data[2:5])

#convert dataframe to list
d = data.values
#print(d)
print(d[2:5,1:4])

sal = d[:,3] #copy sal column
print(sal)

new_sal = []
for s in sal:
    ns = s*1.10
    new_sal.append(ns)

data['new_sal'] = new_sal
print(data)

#write to excel
data.to_excel(r'C:\Users\vkumar15\Documents\TestFolder\emp.xlsx',sheet_name='new_sal', index=False)





    
    





















