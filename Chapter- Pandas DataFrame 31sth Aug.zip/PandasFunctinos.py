import pandas as pd


#read excel
data= pd.read_excel(r'C:\Users\vkumar15\Documents\TestFolder\emp.xlsx',sheet_name='new_sal')
print(data)


#info()
print(data.info())

#show stats: count, mean, sd, min,  25%, 50%, 75% , max 
print(data.describe())

##group by : is data destribuation
print(data.groupby('gender').size())

print(data.groupby('gender').count())
print(data.groupby('gender').max())
print(data.groupby('gender').min())
print(data.groupby('gender').sum())

print(data.groupby('gender').sum()['new_sal'])


#sorting/order by
print(data.sort_values('emp_name',ascending=True))
print(data.sort_values('emp_name',ascending=False))
print(data.sort_values('new_sal',ascending=True))      


#filter
x= data[data['exp']>5]
print(x['emp_name'])




 











