##
##
import pandas 
import matplotlib.pyplot as plt
from sklearn import model_selection


url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']

dataset = pandas.read_csv(url, names=cols)
print(dataset)


#150 rows , 4 numeric, 1 text  

print(dataset.describe())
'''
outliers= greater than mean+sd*3

'''

#dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
dataset.plot(kind='box')
plt.show()

##split

data = dataset.values
X = data[:,0:4]
Y = data[:,4]


X_train, X_validation, Y_train, Y_validation =model_selection.train_test_split(X, Y, test_size=.20, random_state=7)


##model

from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


models = []
#l = LogisticRegression()
#models.append(('lr' ,LogisticRegression()))


models.append(('LR', LogisticRegression()))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))

#l = LogisticRegression()
#l.fit(xtrain,ytain)

for name,model in models:

    kfold = model_selection.KFold(n_splits=10, random_state=7)    
    cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring='accuracy')

    print(name,cv_results.mean(), cv_results.std())

    #model.predict(x_test,y_test)
    
    
    



    
        












     
        
