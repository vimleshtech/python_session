import os #handle the folder and files


src = r'C:\Users\vkumar15\Desktop\ScanAdmin'
o = os.listdir(src)
#print(o)

for  x in o:
     #print(x)
     if x.endswith('.txt'):
          #print(x)
          f  = open(src+'\\'+x,'r')
          print(f.read())
          f.close()
          

#shutil
import shutil
#shutil.move('C:/Users/vkumar15/Desktop/emp.txt','C:/Users/vkumar15/Desktop/ScanAdmin')

#print('file is moved')
import time
for i in range(1,10):
     print(i)
     time.sleep(3)
     
     


