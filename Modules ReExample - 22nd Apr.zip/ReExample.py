#validateion / pattern matching
import re

s = input('enter data :')

o = re.match('(.*) is (.*)',s)

print(o.groups())
print(o.group(1))
print(o.group(2))

if o:
     print('is  match')
else:
     print('not match')
     

#validate email
e = input('enter gmail account :')

o = re.search('@gmail.com$',e)
if o:
     print('valid gmail account')
else:
     print('invalid account')




     
