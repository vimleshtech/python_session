import os

#get list of files and folder from given directory / path 
o = os.listdir(r'C:\Users\vkumar15\Desktop\Learning & Training')
print(o)


##return current folder / working directory
print(os.getcwd())

#change the folder/working path
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')


print(os.getcwd())


