import pandas


cars = pandas.read_csv(r'C:\Users\vkumar15\Desktop\Learning & Training\Weekend\Sunday\mtcars.csv')
print(cars)

#get row and col count
print(cars.shape)

#get columns name
print(cars.columns)


#get data info
print(cars.info())


#get top given rows
print(cars.head()) #default count is 5
print(cars.head(2))
print(cars.head(n=2))

#show from buttom
print(cars.tail(3))


#show selected column
print(cars['model'])
print(cars[['model','hp','wt']])

###
out =cars.corr()
out.to_csv('corr.csv')

#print()

#cars1
#cars2

#car = pandas.frame(cars1,cars2)

















