import random

o = random.randint(1,100)
print(o)


o = random.random()
print(o)


##example
c = ['a','b','c','d','e']
print(c[random.randint(0,4)])

#'11'+name[0:2]+'99'++dob[2:4]+pan[4:7]+'00'


