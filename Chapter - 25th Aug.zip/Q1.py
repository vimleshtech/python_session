a ="this is test file. python is open source langauge"
o = a.split()  #split/break word by word ["this","is"...]

#print(set(o))

l= list(set(o))  #set(o) return unique value 
print(l)

#read data from l to w 
for w in l:
    c = 0
    for aw in o:
        if aw == w:
            c+=1
    print('count of {} is {} '.format(w,c))
    
    
    
    






