n = int(input('enter num :'))


o  = n*n
print(o)

#or
o = n**2
print(o)

