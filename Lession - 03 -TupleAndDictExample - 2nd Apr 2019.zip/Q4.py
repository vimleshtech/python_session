
#take data from user
a = []
for i in range(1,10):
     d = int(input('enter data :'))
     a.append(d)


#get unique list  1,2,1,2,34,5
uq = []
for x in a:
     if x not in uq:
          uq.append(x)

#get count of every unique item : uq = 1 2 34 5
for d in uq:
     c = 0
     for e in a:
          if d == e:
               c +=1

     print('count of ',d,' is ',c)
     

###
a ="this is pythohn"
w = a.split(' ')
print(w)

for word in w:
     
     print( word[::-1],end =' ')
     
     








