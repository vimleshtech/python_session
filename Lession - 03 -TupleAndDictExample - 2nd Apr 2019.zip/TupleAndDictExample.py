t = (11,22,3,44,222,2,33,4)

print(len(t))
print(max(t))
print(min(t))
print(sum(t))

#find or search
d  = int(input('enter data to search  :'))
if d in t:
     print('data is match ')
else:
     print('data is not match ')
     

##iterate the list
for e in t:
     print(e)
#or
for i in range(0,len(t)):
     print(t[i])
     
#dict
d = {'a':100,2:'200',3:'THREE',100:[11,22,33,4]}
print(len(d))
print(d[2])

##
d['d']='delta'

print(d)


###set
s = {1122,33,11,11,22}
print(s)





d = 'this is java'
if d.endswith('java'):
     print('match')
     
           







