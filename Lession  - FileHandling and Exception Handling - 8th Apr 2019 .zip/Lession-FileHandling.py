def write_to_file():
     #file will be created automatically if file doesn't exist
     #w : overwrite
     #a : append 
     f = open('users.txt','a')  # open the file in write mode (overrite the data)
     f.write('hello-2\n')
     
     f.close()

def read_from_file():
     o = open('users.txt','r')#default mode is r 
     #print(o.read())
     #print(o.readline())
     #print(o.readline())

     #data = o.readlines()
     #print(len(data))
     #wap to get row count
     #wap to to get word count
     #wap to get particular word count
     i =0
     wc =0
     pwc =0
     for word in o.readlines():
          print(word)
          col  = word.split(" ")# ["", "", ""]
          wc+=len(col) # col count
          for w in col:
               if w =='is':
                    pwc+=1
          i+=1 #row count 
          
          
          
     print('row count ',i)
     print('col count ',wc)
     print('count of is  ',pwc)
     o.close()
     
     
     

#write_to_file()
read_from_file()


     
     


     
