

try:
     a = int(input('enter data '))
     b = int(input('enter data '))
     if b<0:
          msg = ZeroDivisionError('divisor cannot be less than 0')
          raise msg
          
     #div
     c = a/b
     print(c)

except ValueError as v:
     print(v)
     
except TypeError as e:
     print(e)
except ZeroDivisionError as e:
     print(e)
except:
     #print('error')
     pass
finally:
     a =0
     b =0


#add
c=a+b
print(c)
