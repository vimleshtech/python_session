#wap to get total sal

f = open(r'C:\Users\vkumar15\Desktop\emp.txt')

total  = 0
f.readline()
for r in f.readlines():
     col = r.split(",")
     total += int(col[3])

print('total sal ',total)

     
     



