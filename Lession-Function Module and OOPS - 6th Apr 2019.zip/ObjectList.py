class emp:

     def set_data(a):
          a.eid =  int(input('enter id  :'))
          a.name = input('enter name :')
          a.sal =  int(input('enter sal :'))
                    
     def compute_data(b):
               b.hra = b.sal*.40
               b.da = b.sal*.40
               b.msal =b.hra+b.da+b.sal
               
               b.ysal = b.msal*12

               
               
     def show(c):
          print(c.eid)
          print(c.name)
          print(c.msal)
          print(c.ysal)

e = []
for i in range(0,5):
     o = emp()
     o.set_data()
     o.compute_data()
     e.append(o)

for x in e:
     x.show()
     
     
     
