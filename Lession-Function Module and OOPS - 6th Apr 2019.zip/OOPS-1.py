class compute:

     def test(o):
          print('test function ',o)

     def get_data(a):
          a.a =  int(input('enter data :'))
          a.b =  int(input('enter data :'))
          
          
     def compute_data(b):
               b.c = b.a+b.b
               
     def show(c):
          print(c.c)
          

#create object
o1 = compute()
o2 = compute()
print(o1)
print(o2)

o1.test()
o2.test()

o1.get_data()
o1.compute_data()
o1.show()

