
#- no argument no return
def welcome():
     print('welcome to fun world.. !!!there are multiple function in this file')
     
#- no argument with return
def get_data():
     a = int(input('enter data :'))
     b = int(input('enter data :'))

     return a,b
#- argument with no return
def add(a,b):
     print('sum of two values ',a+b)


#def add(a,b,c):  #this function will overwrite above definition 
#     print('sum of two values ',a+b)



#- argument with return
def sub(a,b):
     return a-b

#- function with default argument
def sum(a,b=0,c=0,d=0,e=0):
     print(a+b+c+d+e)
     
#- function with dynamic argument
def mul(*a):
     o =1
     print(a)
     print(type(a))
     for d in a:
          o*= d
     print(o)

     
#- recussive function
def fact(n):
     if n == 1:
          return n

     else:
          return n*fact(n-1) #4*3*2*1
     
     


#def __main__(): #main is reserved function     
#     welcomme()


#or
welcome()
x,y = get_data()
print(x+y)

add(1,2)

o = sub(11,2)
print(o)
add(o,100)

sum(11)
sum(11,33)
sum(11,44,555)
sum(11,545,333,444)


mul(11,2222,333,4,3,3,2,2,2,3,3,4)

mul(1,2)


f  = fact(5)
print(f)

