def add(a,b):
     print(a+b)

def sub(a,b):
     return a-b

def mul(*a):
     f = 1
     for d in a:
          f*=d

     return f
