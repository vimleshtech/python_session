#Syntax # 1
import Compute

Compute.add(1,2)
o = Compute.sub(11,4)
print(o)


#Syntax # 2
import Compute as c
c.add(11,3)
o = c.sub(444,44445)
print(o)

#Syntax # 3
from Compute import add,sub
add(11,2)
a = sub(44,5)
print(a)


#Syntax  # 4
from Compute import *
add(11,2)
a = mul(44,5,5,4,3)
print(a)




















