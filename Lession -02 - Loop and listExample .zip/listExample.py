a =[11,22,3,333,444,1,12]
print(max(a))
print(min(a))
print(len(a))
print(sum(a))


a.append(100)
print(a)

a.pop()
print(a)

a.insert(2,200)
print(a)

a.remove(3) #by value
print(a)

a.sort() #in memory
print(a)

#slicer
print(a[0])
print(a[0:4])#from 0 to 3
print(a[:4])#from 0 to 3
print(a[-1])#from right 

print(a[::-1]) #in rev   :: righ to left ,  -1 index decrement by 


#remove by index
a[1:3] =[]
print(a)

#declare  empty list
data = []
for i in range(1,10):
     d = int(input('enter data :'))
     data.append(d)

print(data)




             










