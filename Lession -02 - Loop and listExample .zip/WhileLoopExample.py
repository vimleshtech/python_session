#while
i =1
while i < 10:
     print(i)
     i +=1
     
#print in one line
i =1
while i < 10:
     print(i,end=',')
     i +=1

#print in rev
i =10
while i>0:
     print(i)
     i -=1

#print all odd numbers betwee 1 to 30
i =1
while i<30:
     print(i)
     i +=2

#wap to get sum of all even and odd numbers between 1 to 100
i =1
se =0
so =0
while i<=100:
     if i % 2==0:
          se +=i
     else:
          so +=i

     i+=1

print('sum of all even :',se)
print('sum of all odd :',so)

#wap to print table of given no
n = int(input('enter num :'))
i =1
while i<11:
     print(n,'*',i,'=',(n*i))
     i +=1


     





     



          




     






