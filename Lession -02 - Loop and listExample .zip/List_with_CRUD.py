#two dimenssion list with CRUD applicaiton

emp = []

while True:

     ch = input('press 1 for add 2 for show 3 for delete 4 update 5 for exit ')

     if ch =='1':
          row = []
          eid = int(input('enter eid '))
          ename = input('enter name ')
          esal= int(input('enter sal '))

          row.append(eid)
          row.append(ename)
          row.append(esal)
          emp.append(row)

     elif ch =='2':
          for r in emp:
               print(r)

     elif ch== '3':
            eid = int(input('enter eid '))

            #get index of row
            ind =-1
            for  i in range(0,len(emp)):
                 if emp[i][0] == eid:
                      ind =i
                      break

            if ind>-1:
                 emp.remove(emp[i])
            else:
                 print('given id not match')
                 
     elif ch =='4':
            eid = int(input('enter eid '))

            #get index of row 
            for  i in range(0,len(emp)):
                 if emp[i][0] == eid:
                      name = input('enter new name :')
                      sal = input('enter new sal :')
                      emp[i][1] = name
                      emp[i][2] = sal
                      print('data is update')
     elif ch =='5':
          break
     else:
          print('wrong choice !!')
          





                      
                    
                      
          



            
                    


     

     
     
