for i in range(1,11):
     print(i)


#in rev
for i in range(10,1,-1):
     print(i)
     

#get sum of all even and odd
se =0
so =0
for i in range(1,101):
     if i % 2==0:
          se +=i
     else:
          so +=i



print(se)
print(so)

#nested loop : loop inside loop
for r in range(1,5): #for rows
     for c in range(1,4): #for col
          print(c,end='\t')
     print()#new line

'''
1
12
123
'''
for r in range(1,5): #for rows
     for c in range(1,r+1): #for col
          print(c,end='\t')
     print()#new line







     




          







