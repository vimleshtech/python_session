out =1
inc =0

for i in range(1,10):
     print(out)
     out = out+4+inc
     inc+=2


     
     
