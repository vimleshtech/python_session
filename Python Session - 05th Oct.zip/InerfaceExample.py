from  tkinter import *

o = Tk()
o.title('My Test GUI App')
o.geometry("500x700")



fn = Label(text='enter fname :', fg="blue")
fn.pack()

tfn =  Entry()
tfn.pack()



ln = Label(text='enter lname :')
ln.pack()


tln =  Entry()
tln.pack()

msg = Label(text='jgghf')
msg.pack()
#o.grid(msg,0,1)

def event():
    print('you have clicked on button')
    fn = tfn.get()
    ln = tln.get()
    fullname = fn+' '+ln
    print('name is  ',fullname)
    msg.configure(text=fullname)
    

b = Button(text='click me',command=event)
b.pack()


o.mainloop()


