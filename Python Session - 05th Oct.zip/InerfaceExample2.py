from  tkinter import *

o = Tk()
o.title('My Test GUI App')
o.geometry("500x700")


fn = Label(text='enter fname :', fg="blue")
fn.grid(row=0,column=1)

tfn =  Entry()
tfn.grid(row=0,column=0)

o.mainloop()


