import time
'''
Thread : is process
Multi Threading : multiple process

'''

import threading

def p1():
    for i in range(1,5):
        print(i,end='')
        #time.sleep(3)


def p2():
    for i in range(11,15):
        print(i,end='')
        #time.sleep(3)



#p1()
#p2()
t1 = threading.Thread(target=p1,name='task1')
t2 = threading.Thread(target=p2,name='task2')

t1.start()
t2.start()








    
    
        
