import requests
from bs4 import BeautifulSoup


res = requests.get('https://www.imdb.com/search/title/?genres=drama&groups=top_250&sort=user_rating,desc')
print(res.status_code)

html = BeautifulSoup(res.text,'html.parser')
print(html)

out = html.find_all('div',{'class':'lister-item mode-advanced'})
print(len(out))

for mi in out:
    #h1 = mi.find_all('div',{'class':'lister-item-content'})
    #print(h1)
    #print(len(h1))
    #a1 = h1.find_all('a')
    print(mi.h3.a.text)
    #break




