import pandas
import matplotlib.pyplot as plt

#read csv file
emp = pandas.read_csv(r'C:\Users\hp\Desktop\csv\emp.csv')

print(emp)

#extract three columns
nd = emp[['age','exp','salary']]

print(nd)


##corr
print(nd.corr())


##
#nd.plot() #default is line chart
#nd.plot(kind='bar')
#nd.plot(kind="box")
#nd.plot(kind="bar",subplots=True)
nd.plot(kind="bar",subplots=True,layout=(1,3))

plt.show()





