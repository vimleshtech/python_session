import numpy


#create array 
o = numpy.arange(10) #from 0 to 9
print(o)
print(type(o))


x = [11,22,44,55,66,77,44]
print(x)
print(type(x))


#convert list to array
y = numpy.array(x)
print(y)


##list and array operation
print(x*2) #list
print(y*2) #array

print(y*1.20)


##shape
print(y.shape)

###generate the array of 0,1
o = numpy.zeros(10)
print(o)


o = numpy.ones(10)
print(o)


##multiple dimenssion
data = [[11,222,44,545,5],[333,455,333,44,55]]
print(data)
o = numpy.array(data)
print(o)

print(o*4)

####
print(o.shape) #row,col

###multiple array math
o2 = o*2

print(o)
print(o2)

print(numpy.add(o,o2))
print(numpy.subtract(o,o2))
print(numpy.divide(o,o2))
print(numpy.multiply(o,o2))



####
hours = [5,6,8,9,2,3,7,0]
marks = [50,60,80,90,23,43,75,0]


hours = numpy.array(hours)
marks = numpy.array(marks)

print(hours)
print(marks)
print(hours.shape)
print(marks.shape)


hours = numpy.array(hours).reshape(-1,2)
print(hours)


print(hours.shape)









































































 
