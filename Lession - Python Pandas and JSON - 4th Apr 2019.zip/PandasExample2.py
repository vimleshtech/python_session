import pandas as pd

url = "iris.csv"

cols = ['a', 'b', 'c', 'd', 'class']
test = pd.read_csv(url, names=cols)
print(test.shape)

print(test.head())
print(test.tail())

print(test.groupby('class').size())

out  = test.corr()

out.to_csv('corr_output.csv')


