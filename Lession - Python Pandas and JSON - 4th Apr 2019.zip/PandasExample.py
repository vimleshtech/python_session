#import pandas
import pandas as pd

#create empty dataframe (table)

#Example:1
data  = pd.DataFrame()
print(data)

#create dataframe from list using dict
#Example:2
eid  = [1,2,3,4,5]
ename  = ['nitin','jatin','divya','ayush','nitisha']
esal  = [13333,444442,33333,44444,222225]
egender  = ['male','male','female','male','female']

emp  = pd.DataFrame(data={'empid':eid,'name':ename,'gender':egender,'bsal':esal})

print(emp)

##get list of columns
print(emp.columns)

#get top given rows
print(emp.head(n=3)) #default 5 rows

#get  row from buttom (default is 5 )
print(emp.tail(n=2))


#get/print particular column
print(emp['name'])

#get multiple columns
print(emp[['name','bsal','gender']])


### convert data to series format/list
data  = emp.values
print(data[:,1:4]) #row,col   (: , - all rows )

print(data[2:4:,:]) #row,col   (: , - all rows )

##order / sorting
d = emp.sort_values(by='bsal',ascending=True)
print(d)
d = emp.sort_values(by='bsal',ascending=False)
print(d)


d = emp.sort_values('name',ascending=True)
print(d)

##group by
print(emp.groupby('gender').count())
print(emp.groupby('gender').size())

print(emp.groupby('gender').sum())

print(emp.groupby('gender').sum()['bsal'])
print(emp.groupby('gender').max()['bsal'])
print(emp.groupby('gender').min()['bsal'])

##get stats
'''
count
mean/avg
std dev
min / 0%
25 %
50%
75%
max 100%
'''

print(emp.describe())


#correlation
# -1  to +1
# -1 : negative
# +1 : positive
# 0 : no corrr.


print(emp.corr())


#search/filter
emp.iloc[emp['bsal']>34000]
     





                

























