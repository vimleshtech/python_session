#https://www.amazon.in/s?k=iphone&ref=nb_sb_noss_2
#https://www.flipkart.com/search?q=iphone&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off

import requests
from bs4 import BeautifulSoup

o = requests.get('https://in.yahoo.com/?p=us')
print(o)  #status_code = 200

print(o.status_code)
print(o.text)

'''
<html>
    <head> .. </head>
    <body> ..
    <a> ...

    <a> ....

    <a> ... 
</html>

tag,class, 

'''

html = BeautifulSoup(o.text,'html.parser')

#print(html)
out = html.find_all('a')
print(len(out))

for o in out:
    #print(o.text, o.get('href'))
    print(o.get('href'))
    

#x = html.find_all('div',_class='_1vC4OE _2rQ-NK')










