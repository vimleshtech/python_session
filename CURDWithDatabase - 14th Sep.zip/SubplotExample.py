import pandas as pd
import matplotlib.pyplot as plt

e = pd.read_csv(r'C:\Users\vkumar15\Documents\TestFolder\employee_data.csv')

#e.plot(kind='bar',subplots=True)
e.plot(kind='bar',subplots=True,layout=(1,2)) #one row and 2 cols
plt.show()





