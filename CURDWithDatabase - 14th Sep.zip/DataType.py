import numpy as np

x = ['11','222','4444']


o = np.array(x)
print(o)


#change data type
o = np.array(x,dtype=float)
print(o)

