import pandas as pd

e = pd.read_csv(r'C:\Users\vkumar15\Documents\TestFolder\employee_data.csv')
print(e)

e.to_csv('file_name.csv') #write to csv

#read frome excel
e = pd.read_excel(r'C:\Users\vkumar15\Documents\TestFolder\employee_data.xlsx',sheet='Sheet1')
print(e)
e.to_excel('my_excel.xlsx',sheet='TestSheet')




