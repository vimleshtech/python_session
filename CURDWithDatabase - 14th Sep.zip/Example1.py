import pandas as pd
import matplotlib.pyplot as plt

emp = pd.read_csv('employee_data.csv')
print(emp)


print(emp.corr())

emp.plot(kind='bar',subplots=True)
plt.show()


