import mysql.connector as con
c = con.connect(host='localhost',user='root',password='root',database='test99')
cur = c.cursor()

def create():
    cid = input('enter cid:')
    name = input('enter name:')
    age = input('enter age:')
    gender = input('enter gender:')
    
    cur.execute("insert into customer(cid,name,age,gender) values({},'{}',{},'{}');".format(cid,name,age,gender))
    c.commit()
    print('data is saved')
    
     
    


def show():
    cur.execute("select * from customer")
    o = cur.fetchall()
    print(cur.column_names)
    for r in o:
        print(r)
        

    

def delete():
    cid = input('enter cid which you want to remove :')
    cur.execute("delete from customer where cid ={} ".format(cid))
    c.commit()
    print('row is removed')

    


def update():
    cid = input('enter existing cid:')
    name = input('enter new name:')
    age = input('enter new age:')
    gender = input('enter ne gender:')
    
    cur.execute("update customer set name='{}',age={},gender='{}' where cid ={}".format(name,age,gender,cid))
    c.commit()
    print('data is modified')
    

while True:
    ch = input('press 1 for create new row, 2 for show 3 for delete 4 for update and 0 of exit ')
    if ch=='1':
        create()


    elif ch=='2':
        show()


    elif ch=='3':
        delete()


    elif ch =='4':
        update()
        


    elif ch=='0':
            break 

    else:
        print('Invlid choice  , plz try again !!!')
        

