i = 1 #init
while i<10: #condition
     #print(i)  #print new line
     print(i,end=',')
     i+=1  #increment


# 1 2 .. 9
#print in reverse
i =10
while i>0:
     print(i)
     i-=1

#print odd numbers between 1 to 30
i =1
while i<30:
     print(i)
     i +=2

#wap to get sum of all even and odd numebrs between 1 to 100
se =0
so =0
i =1
while i<=100:

     if i % 2 ==0: #if no is even 
          se +=i
     else:
          so +=i

     i+=1

print('sum of all even no:',se)
print('sum of all odd no:',so)

############# for loop ######
for x in range(1,10): # from 1 to 10, default incremeter is 1
     print(x)
     
for x in range(1,10,2):
     print(x)
#in rev
for x in range(10,0,-1):  #from 10 to  >0
     print(x)





     



     

     











     


          



          



     






     
     

     
     
